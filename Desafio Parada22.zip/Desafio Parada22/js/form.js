function  validacao() {
    let nome=document.getElementById("nome");
    let ncartao=document.getElementById("numero_cartao");
    let dataValidade=document.getElementById("data_validade");
    let cValidade=document.getElementById("cvv");
    let emmail1=document.getElementById("i-email");
    let conEmail=document.getElementById("i_email");

    estilo_input(nome,"#f45656","#808080");
    estilo_input(ncartao,"#f45656","#808080");
    estilo_input(dataValidade, "#f45656","#808080");
    estilo_input(cValidade,"#f45656","#808080");
    estilo_input(emmail1,"#f45656","#808080");
    estilo_input(conEmail,"#f45656","#808080");
}
function estilo_input(input,cor_1,cor_2){
    if(input.checkValidity()){
        alert.style.display="block";
        return input.style.border=`3px solid ${cor_1}`;
    }else{
        return input.style.border=`1px solid ${cor_2}`;
    }
     
   
}